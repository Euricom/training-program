<template>
  <div class="basket">
    <h1>Basket</h1>
    <table>
      <thead>
        <tr>
          <th>Title</th>
          <th>Quantity</th>
          <th>Price</th>
          <th>Total</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in basket.items"
            :key="item.id">
          <td>{{item.title}}</td>
          <td>{{item.quantity}}</td>
          <td>{{item.price | euro}}</td>
          <td>{{item.getTotalPrice() | euro}}</td>
          <td><button class="btn-danger"
                    @click="onRemove(item)">Delete</button></td>
        </tr>
      </tbody>
    </table>
    <h4>The grand total price: {{basket.getTotalPrice() | euro}}</h4>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { Product } from '@/models/product';
import { BasketModel } from '@/models/basket';
import { BasketItem } from '@/models/basketItem';

import {
  getBasket,
  addProduct,
  removeProduct,
} from '@/services/basket.service';
import { getProductById } from '@/services/product.service';
import { eventBus } from '@/main';

@Component
export default class Basket extends Vue {
  basket: BasketModel = new BasketModel();

  async created() {
    this.basket = await getBasket();
    this.basket.items.forEach(async item => {
      const product = await getProductById(item.id);
      item.setProductInfo(product);
    });

    eventBus.$on('productAdded', async product => {
      const updatedBasket = await addProduct(product.id, 1);
      this.basket.addProductToBasket(product, 1);
    });
  }

  async onRemove(basketItem: BasketItem) {
    await removeProduct(basketItem);
    this.basket.items = this.basket.items.filter(itemInBasket => {
      return itemInBasket.id !== basketItem.id;
    });
  }
}
</script>

<style scoped lang="scss">
span {
  margin-right: 5px;
}
td {
  border: 1px solid rgb(209, 209, 209);
  padding: 10px 20px;
}
</style>
