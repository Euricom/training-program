<template>
  <div class="product">
    <h2>{{ product.title }}</h2>
    <img :src="product.image" />
    <p>{{ product.desc }}</p>
    <div class="checkbox-wrapper">
      <input type="checkbox"
             id="stocked"
             disabled
             v-model="product.stocked">
      <label for="checkbox">In stock</label>
    </div>
    <p v-if="product.hasDiscount">Base price: {{
      product.basePrice | euro}}</p>
    <p v-if="product.hasDiscount">Discount: {{
      product.getDiscount() | percentage}}</p>
    <p>Price: {{ product.price | euro }}</p>
    <button @click="onAdd(product)">Add</button>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { Product } from '../models/product';

import { eventBus } from '@/main';

@Component
export default class ProductPanel extends Vue {
  @Prop()
  private product: Product;

  onAdd(product: Product) {
    console.log('test');
    eventBus.$emit('productAdded', product);
  }
}
</script>

<style scoped lang="scss">
h2 {
  margin: 40px 0 5px;
  font-weight: 800;
}
.product {
  //display: flex;
  //align-items: flex-start;
  text-align: left;
  margin: 10px;
}
button {
  background-color: #497ab9;
  color: #fff;
  border-radius: 7px;
  border: none;
  font-weight: bold;
  margin-top: 20px;
  padding: 10px;
}
</style>
