<template>
  <div>
    <h1>Product List</h1>
    <ul>
      <li v-for="product in products"
          :key="product.id">
        <ProductPanel :product="product" />
      </li>
    </ul>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { getAllProducts } from '../services/product.service';

import { Product } from '../models/product';

import ProductPanel from '@/components/ProductPanel.vue';

@Component({
  components: {
    ProductPanel,
  },
})
export default class ProductList extends Vue {
  private products: Product[] = [];

  created() {
    getAllProducts().then(products => {
      this.products = products;
    });
  }
}
</script>


<style lang="scss" scoped>
ul {
  padding: 0;

  display: flex;
  justify-content: flex-start;
  align-items: flex-start;
  flex-wrap: wrap;

  width: 100%;
}
li {
  list-style-type: none;
  width: 400px;
}
</style>
