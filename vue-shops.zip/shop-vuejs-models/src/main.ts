import '@babel/polyfill';
import Vue from 'vue';
import './plugins/vuetify';
import './plugins/vuelidate';

import App from './App.vue';
import router from './router';
import store from './store';

Vue.config.productionTip = false;

Vue.filter('euro', (price: any) => {
  if (!price) {
    return price;
  }

  const rawValue = parseFloat(price);
  if (isNaN(rawValue)) {
    return price;
  }

  return '€' + rawValue.toFixed(2);
});

Vue.filter('percentage', (value: any) => {
  if (!value) {
    return value;
  }
  return `${value.toFixed(0)}%`;
});

/* Simple Event Bus
 * use:
 *    // in component A
 *    eventBus.$emit('resourceAdded', resoure)
 *
 *    // in component B
 *    eventBus.$on('resourceAdded', (resource) => {
 *      console.log('the resource is added', resource)
 *    })
 */
export const eventBus = new Vue();

new Vue({
  router,
  store,
  render: h => h(App),
}).$mount('#app');
