import axios from 'axios';
import { BasketModel } from '@/models/basket';
import { BasketItem } from '@/models/basketItem';

const baseUrl = 'http://localhost:3000';
const key = '2390Malle';

export const getBasket = async (): Promise<BasketModel> => {
  // return axios
  //   .get<any>(`${baseUrl}/api/basket/${key}`)
  //   .then(response => {
  //     return new BasketModel(response.data);
  //   })
  //   .catch(e => {
  //     console.log('Failed to get ALL products');
  //     throw e;
  //   });

  const response = await axios.get<any>(`${baseUrl}/api/basket/${key}`);
  return new BasketModel(response.data);
};

// NOT USED
// export const updateQuantity = async (id: number): Promise<any> => {
//   const res = await axios.patch<any>(
//     `${baseUrl}/api/basket/${key}/product/${id}`,
//   );
//   return res.data[0];
// };

export const addProduct = async (
  id: number,
  quantity: number,
): Promise<any> => {
  try {
    const res = await axios.post<any>(
      `${baseUrl}/api/basket/${key}/product/${id}`,
      { quantity: quantity },
    );
    return res.data[0];
  } catch (error) {
    return false;
  }
};

export const removeProduct = async (basketItem: BasketItem): Promise<void> => {
  const res = await axios.delete(
    `${baseUrl}/api/basket/${key}/product/${basketItem.id}`,
  );
};
