<template>
  <div>
    <h1>Product Table</h1>
    <table class="table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Price</th>
          <th>In stock</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="product in products"
            :key="product.id"
            v-on:click="goToProductDetail(product)">
          <td>{{product.title}}</td>
          <td>{{product.price | euro}}</td>
          <td>{{product.stocked}}</td>
          <td><button class="btn-danger"
                    v-on:click.stop="removeProduct(product)">Remove</button></td>
        </tr>
      </tbody>
    </table>
    <button class="btn-success"
            v-on:click="addProduct()">Add product</button>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { getAllProducts, removeProductById } from '@/services/product.service';

import { Product } from '@/models/product';

@Component({})
export default class ProductList extends Vue {
  products: Product[] = [];

  // hooks
  created() {
    getAllProducts().then(products => {
      this.products = products;
    });
  }

  // methods
  goToProductDetail(product) {
    this.$router.push({ name: 'productDetail', params: { id: product.id } });
  }

  addProduct() {
    this.$router.push({ name: 'productAdd' });
  }

  removeProduct(product) {
    const answer = confirm('Are you sure you wish to delete?');
    if (answer) {
      removeProductById(product.id).then(status => {
        this.products = this.products.filter(productInTable => {
          return productInTable.id !== product.id;
        });
      });
    }
  }
}
</script>


<style lang="scss" scoped>
h1 {
  margin-bottom: 10px;
}
.table {
  width: 800px;
  margin: 0 auto;
  display: block;
  height: 600px;
  overflow-y: scroll;
  border: 1px solid #d6d6d6;
  border-collapse: collapse;

  thead tr {
    background: rgb(228, 228, 228);
  }

  tbody tr {
    cursor: pointer;

    &:hover {
      background: rgb(238, 238, 238);
    }
  }

  th {
    height: 30px;
    width: 200px;
  }

  td {
    height: 30px;
    padding: 5px;
    border-bottom: 1px solid rgb(228, 228, 228);
  }
}
</style>
