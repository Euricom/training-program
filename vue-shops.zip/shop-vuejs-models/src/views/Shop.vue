<template>
  <section class="wrapper">
    <ProductsList />
    <Basket />
  </section>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import ProductsList from '@/components/ProductsList.vue'; // @ is an alias to /src
import Basket from '@/components/Basket.vue';

@Component({
  components: {
    ProductsList,
    Basket,
  },
})
export default class Shop extends Vue {}
</script>

<style lang="scss" scoped>
.wrapper {
  display: flex;
  justify-content: flex-start;
  flex-direction: row;
}
</style>
