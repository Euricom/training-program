<template>
  <div id="app">
    <div id="nav">
      <router-link to="/">Shop</router-link> |
      <router-link to="/products">Products</router-link>
    </div>
    <router-view />
  </div>
</template>

<style lang="scss">
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
#nav {
  padding: 30px;
  a {
    font-weight: bold;
    color: #2c3e50;
    &.router-link-exact-active {
      color: #42b983;
    }
  }
}

h1 {
  font-size: 2rem;
}

h2 {
  margin: 40px 0 5px;
  font-weight: 800;
}

li {
  list-style-type: none;
}

button.btn-success,
input[type='submit'] {
  background-color: #90d6b0;
  color: #fff;
  border-radius: 7px;
  border: none;
  font-weight: bold;
  margin-top: 20px;
  min-width: 200px;
  min-height: 35px;
}

.btn-danger {
  background: #bb2a2a;
  color: #fff;
  padding: 5px 10px;
  border-radius: 3px;
}
</style>
