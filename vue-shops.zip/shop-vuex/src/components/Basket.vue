<template>
  <div class="basket">
    <h1>Basket</h1>
    <table>
      <thead>
        <tr>
          <th>Title</th>
          <th>Quantity</th>
          <th>Price</th>
          <th>Total</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in basket.items"
            :key="item.id">
          <td>{{item.title}}</td>
          <td>{{item.quantity}}</td>
          <td>{{item.price | euro}}</td>
          <td>{{item.totalPrice | euro}}</td>
          <td><button class="btn-danger"
                    @click="onRemove(item)">Delete</button></td>
        </tr>
      </tbody>
    </table>
    <h4>The grand total price: {{basket.totalBasketPrice | euro}}</h4>

    <button class="btn"
            @click="incrementCount()">incrementCount</button>

    <div class="count">{{count}}</div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { Product } from '@/models/product';

import { mapActions } from 'vuex';
import { State, Getter, Action } from 'vuex-class';

import { BasketModel } from '@/models/basket';
import { BasketItem } from '@/models/basketItem';

import {
  getBasket,
  addProduct,
  removeProduct,
} from '@/services/basket.service';
import { getProductById } from '@/services/product.service';
import { eventBus } from '@/main';

@Component({
  // methods: {
  //   ...mapActions(['increment']),
  // },
})
export default class Basket extends Vue {
  @Getter('count')
  getterCount;
  @Getter('fullBasket')
  basket;

  @Action('increment')
  increment: any;
  @Action('getBasket')
  getBasket;

  //basket: BasketModel = new BasketModel();

  async created() {
    // this.basket = await getBasket();
    // this.basket.items.forEach(async item => {
    //   const product = await getProductById(item.id);
    //   item.setProductInfo(product);
    // });

    this.getBasket();
  }

  async onRemove(basketItem: BasketItem) {
    await removeProduct(basketItem);
    this.basket.items = this.basket.items.filter(itemInBasket => {
      return itemInBasket.id !== basketItem.id;
    });
  }

  incrementCount() {
    // this.$store.commit('increment', { amount: 10 });
    // this.$store.commit({
    //   type: 'increment',
    //   amount: 10,
    // });
    //this.$store.dispatch('increment', { amount: 10 });
    //this.$store.dispatch('addProduct', { quantity: 1 });

    this.increment({ amount: 5 });
  }

  get count(): number {
    return this.getterCount;
  }
}
</script>

<style scoped lang="scss">
span {
  margin-right: 5px;
}
td {
  border: 1px solid rgb(209, 209, 209);
  padding: 10px 20px;
}
.btn {
  background: hotpink;
  color: #fff;
  padding: 5px 10px;
  border-radius: 3px;
  margin-top: 100px;
}
.count {
  margin-top: 10px;
  font-size: 20px;
}
</style>
