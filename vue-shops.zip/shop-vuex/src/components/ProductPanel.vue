<template>
  <div class="product">
    <h2>{{ product.title }}</h2>
    <img :src="product.image" />
    <p>{{ product.desc }}</p>
    <div class="checkbox-wrapper">
      <input type="checkbox"
             id="stocked"
             disabled
             v-model="product.stocked">
      <label for="checkbox">In stock</label>
    </div>
    <p v-if="product.hasDiscount">Base price: {{
      product.basePrice | euro}}</p>
    <p v-if="product.hasDiscount">Discount: {{
      product.getDiscount() | percentage}}</p>
    <p>Price: {{ product.price | euro }}</p>
    <button @click="onAddProduct(product)">Add</button>
    <br>
    <br>
    <div>{{count}}</div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue, Emit } from 'vue-property-decorator';
import { Product } from '../models/product';

import { Getter } from 'vuex-class';

@Component
export default class ProductPanel extends Vue {
  @Getter('count')
  getterCount;

  @Prop()
  product: Product;

  onAddProduct(product: Product) {
    this.$emit('addProduct', product);
  }

  get count() {
    return this.getterCount;
  }
}
</script>

<style scoped lang="scss">
h2 {
  margin: 40px 0 5px;
  font-weight: 800;
}
.product {
  text-align: left;
  margin: 10px;
}
button {
  background-color: #497ab9;
  color: #fff;
  border-radius: 7px;
  border: none;
  font-weight: bold;
  margin-top: 20px;
  padding: 10px;
}
</style>
