<template>
  <ProductsList :products="products"
                @addProduct="onAddProduct($event)" />
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { Action, Getter } from 'vuex-class';
import { IRootState } from '../store';

import { Product } from '../models/product';

import ProductsList from '@/components/ProductsList.vue';

@Component({
  components: {
    ProductsList,
  },
})
export default class ProductList extends Vue {
  //product: Product = new Product();

  @Getter('productItems')
  products: Product[];

  @Action('getProducts')
  getProducts;

  @Action('addProduct')
  addProduct;

  created() {
    this.getProducts();
  }

  onAddProduct(product) {
    console.log('add product in container', product);
    this.addProduct(product);
  }

  // ipv getter rechtstreeks de store benaderen...
  // get products2() {
  //   return (this.$store.state as IRootState).products.items;
  // }
}
</script>

<style lang="scss" scoped>
</style>
