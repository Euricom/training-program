import { BasketItem } from '@/models/basketItem';
import { Product } from '@/models/product';

export class BasketModel {
  items: BasketItem[] = [];

  constructor(items?: any) {
    if (items) {
      this.items = items;
      this.items = this.items.map(item => {
        return new BasketItem({ id: item.id, quantity: item.quantity });
      });
    }
  }

  addProductToBasket(product: Product, quantity: number) {
    const foundBasketItem: BasketItem = this.items.find(itemInBasket => {
      return itemInBasket.id === product.id;
    });

    if (foundBasketItem) {
      foundBasketItem.increaseQuantity();
      return;
    }

    const newItem = new BasketItem({ id: product.id, quantity: quantity });
    newItem.setProductInfo(product);
    this.items.push(newItem);
  }

  getTotalPrice() {
    let totalPrice = 0;
    this.items.forEach(item => {
      totalPrice += item.getTotalPrice();
    });
    return totalPrice;
  }
}
