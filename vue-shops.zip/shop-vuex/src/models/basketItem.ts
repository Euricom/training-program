import { Product } from '@/models/product';

export class BasketItem {
  id: number;
  quantity: number;
  title: string = '';
  price: number = 0;

  constructor(data: any) {
    Object.assign(this, data);
  }

  setProductInfo(product: Product) {
    this.title = product.title;
    this.price = product.price;
  }

  increaseQuantity(): void {
    this.quantity++;
  }

  getTotalPrice(): number {
    return this.price * this.quantity;
  }
}
