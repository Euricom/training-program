import { IProductDto } from '@/services/product.service';

export class Product {
  id: number;
  sku: string;
  title: string;
  desc: string;
  image: string;
  stocked: boolean;
  basePrice: number;
  price: number;

  constructor(productDto?: IProductDto) {
    if (productDto) {
      Object.assign(this, productDto);
    }
  }

  isNew() {
    return !this.id;
  }

  getDiscount(): number {
    const difference: number = this.basePrice - this.price;
    const discount: number = (difference / this.basePrice) * 100;
    return discount;
  }

  get hasDiscount(): boolean {
    return this.getDiscount() > 0;
  }
}
