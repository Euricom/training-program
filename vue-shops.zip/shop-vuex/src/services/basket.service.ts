import axios from 'axios';
import { BasketModel } from '@/models/basket';
import { BasketItem } from '@/models/basketItem';

const baseUrl = 'http://localhost:3000';
const key = '2390Malle';

export const getBasket = async (): Promise<BasketModel> => {
  const response = await axios.get<any>(`${baseUrl}/api/basket/${key}`);
  return new BasketModel(response.data);
};

export const addProduct = async (
  id: number,
  quantity: number,
): Promise<any> => {
  try {
    const res = await axios.post<any>(
      `${baseUrl}/api/basket/${key}/product/${id}`,
      { quantity: quantity },
    );
    return res.data[0];
  } catch (error) {
    return false;
  }
};

export const removeProduct = async (basketItem: BasketItem): Promise<void> => {
  const res = await axios.delete(
    `${baseUrl}/api/basket/${key}/product/${basketItem.id}`,
  );
};
