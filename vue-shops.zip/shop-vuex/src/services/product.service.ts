import axios, { AxiosResponse } from 'axios';

import { Product } from '@/models/product';

const baseUrl = 'http://localhost:3000';

export interface IProductsDto {
  total: number;
  page: number;
  pageSize: number;
  selectedProducts: IProductDto[];
}

export interface IProductDto {
  id: number;
  sku: string;
  title: string;
  desc: string;
  image: string;
  stocked: boolean;
  basePrice: number;
  price: number;
}

export const getAllProducts = (): Promise<Product[]> => {
  return axios
    .get<IProductsDto>(`${baseUrl}/api/products`)
    .then(response => {
      return response.data.selectedProducts.map(productData => {
        return new Product(productData);
      });
    })
    .catch(e => {
      console.log('Failed to get ALL products');
      throw e;
    });
};

export const getProductById = (id: string | number): Promise<Product> => {
  return axios
    .get<IProductDto>(`${baseUrl}/api/products/${id}`)
    .then(response => {
      return new Product(response.data);
    })
    .catch(e => {
      console.log('Failed to get product');
      throw e;
    });
};

export const removeProductById = (id: string | number): Promise<Product> => {
  return axios
    .delete(`${baseUrl}/api/products/${id}`)
    .then(response => {
      return new Product(response.data);
    })
    .catch(e => {
      console.log('Failed to DELETE product');
      throw e;
    });
};

const updateProduct = (product: Product): Promise<Product> => {
  return axios
    .put(`${baseUrl}/api/products/${product.id}`, {
      sku: product.sku,
      title: product.title,
      basePrice: product.basePrice,
      price: product.price,
      stocked: product.stocked,
      desc: product.desc,
      image: product.image,
    })
    .then(response => {
      return new Product(response.data);
    })
    .catch(e => {
      console.log('Failed to UPDATE product');
      throw e;
    });
};

const addProduct = (product: Product): Promise<Product> => {
  return axios
    .post(`${baseUrl}/api/products`, {
      sku: product.sku,
      title: product.title,
      basePrice: product.basePrice,
      price: product.price,
      stocked: product.stocked,
      desc: product.desc,
      image: product.image,
    })
    .then(response => {
      return new Product(response.data);
    })
    .catch(e => {
      console.log('Failed to ADD product');
      throw e;
    });
};

export const saveProduct = (product: Product): Promise<Product> => {
  if (product.isNew()) {
    return addProduct(product);
  }
  return updateProduct(product);
};
