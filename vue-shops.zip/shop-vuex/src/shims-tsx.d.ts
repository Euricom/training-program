import Vue, { VNode } from 'vue';

declare global {
  namespace JSX {
    // tslint:disable no-empty-interface
    interface Element extends VNode {}
    // tslint:disable no-empty-interface
    interface ElementClass extends Vue {}
    interface IntrinsicElements {
      [elem: string]: any;
    }
  }
}

declare module 'vue/types/vue' {
  // Global properties can be declared on the `VueConstructor` interface
  // interface VueConstructor {
  //   $myGlobal: any; // define real typings here if you want
  // }
  // Instance properties
  interface Vue {
    $v: any;
  }

  // https://gist.github.com/wagich/aa0b847c7ab45c61bd11d6cb0d16e4c1
}
