declare module '*.vue' {
  import Vue from 'vue';
  export default Vue;
}

declare module 'vuelidate';
// https://gist.github.com/wagich/aa0b847c7ab45c61bd11d6cb0d16e4c1
