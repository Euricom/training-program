import Vue from 'vue';
import Vuex, { StoreOptions } from 'vuex';

import { getAllProducts, saveProduct } from '@/services/product.service';
import { getBasket } from '@/services/basket.service';

Vue.use(Vuex);

// mutations
const PRODUCTS_LOADED = '✅ Products Loaded';
const PRODUCT_ADDED = '➕ Product Added';
const BASKET_LOADED = '✅ Basket Loaded';

interface IProductsState {
  total: number;
  items: any[];
}

interface IBasketState {
  items: any[];
  total: number;
}

export interface IRootState {
  products: IProductsState;
  basket: IBasketState;
  count: number;
}

const store: StoreOptions<IRootState> = {
  state: {
    products: {
      total: 0,
      items: [],
    },
    basket: {
      items: [],
      total: 0,
    },
    count: 0,
  },
  getters: {
    count: state => {
      return state.count;
    },
    productItems: state => {
      return state.products.items;
    },
    fullBasket: state => {
      let items = state.basket.items;
      items = items.map(item => {
        const product = state.products.items.find(product => {
          return product.id === item.id;
        });
        if (product) {
          return (item = {
            ...item,
            title: product.title,
            price: product.price,
            totalPrice: product.price * item.quantity,
          });
        }
      });

      return {
        items: items,
        totalBasketPrice: getTotalPrice(items),
      };

      function getTotalPrice(items) {
        let total = 0;
        items.forEach(item => {
          total += item.totalPrice;
        });
        return total;
      }
    },
  },
  mutations: {
    increment(state, payload) {
      state.count += payload.amount;
    },
    [PRODUCTS_LOADED](state, payload) {
      state.products.items = payload;
      state.products.total = payload.length;
    },
    [PRODUCT_ADDED](state, payload) {
      state.basket.items.push(payload);
    },
    [BASKET_LOADED](state, payload) {
      state.basket.items = payload.items;
      state.basket.total = payload.items.length;
    },
  },
  actions: {
    increment({ commit }, amount) {
      setTimeout(() => {
        commit('increment', amount);
      }, 1000);
    },
    async getProducts(store) {
      const products = await getAllProducts();
      store.commit(PRODUCTS_LOADED, products);
    },
    async addProduct(store, product) {
      await saveProduct(product);
      store.commit(PRODUCT_ADDED, {
        quantity: 1,
        id: product.id,
      });
    },
    async getBasket(store) {
      const basket = await getBasket();
      store.commit(BASKET_LOADED, basket);
    },
  },
};

export default new Vuex.Store(store);
