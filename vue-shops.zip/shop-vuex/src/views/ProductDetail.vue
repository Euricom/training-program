<template>
  <div class="productDetail">
    <h1>Product detail</h1>
    <form action=""
          v-on:submit.prevent="onSubmit">
      <div class="form-goup"
           :class="{ 'form-group--error': $v.title.$error }">
        <label for="title">Title:</label>
        <input id="title"
               type="text"
               v-model="$v.title.$model">
        <p class="error"
           v-if="!$v.title.required && $v.title.$error">The
          title field is required!</p>
      </div>
      <div class="form-goup"
           :class="{ 'form-group--error': $v.sku.$error }">
        <label for="sku">Sku:</label>
        <input id="sku"
               type="text"
               v-model="$v.sku.$model">
        <p class="error"
           v-if="!$v.sku.required && $v.sku.$error">The sku field is
          required!</p>
      </div>
      <div class="form-goup"
           :class="{ 'form-group--error': $v.desc.$error }">
        <label for="desc">Description:</label>
        <textarea id="desc"
                  type="text"
                  v-model="$v.desc.$model"></textarea>
        <p class="error"
           v-if="!$v.desc.required && $v.desc.$error">The
          description field is required!</p>
      </div>
      <div class="form-goup"
           :class="{ 'form-group--error': $v.image.$error }">
        <label for="title">Image url:</label>
        <input id="title"
               type="text"
               v-model="$v.image.$model">
        <p class="error"
           v-if="!$v.image.required && $v.image.$error">The
          image src is required!</p>
      </div>
      <div class="form-goup"
           :class="{ 'form-group--error': $v.basePrice.$error }">
        <label for="basePrice">Base price:</label>
        <input id="basePrice"
               type="number"
               step=".01"
               v-model.number="$v.basePrice.$model">
        <p class="error"
           v-if="!$v.basePrice.required && $v.basePrice.$error">The
          basePrice is required!</p>
      </div>
      <div class="form-goup"
           :class="{ 'form-group--error': $v.price.$error }">
        <label for="price">Price:</label>
        <input id="price"
               type="number"
               step=".01"
               v-model.number="$v.price.$model">
        <p class="error"
           v-if="!$v.price.required && $v.price.$error">The
          price is required!</p>
      </div>
      <div class="form-goup inline">
        <label for="inStock">In stock:</label>
        <input id="inStock"
               type="checkbox"
               v-model="$v.stocked.$model">
        <p class="error"
           v-if="!$v.stocked.required && $v.stocked.$error">Is the product in
          stock?
        </p>
      </div>
      <div class="form-goup">
        <input class="btn-success"
               type="submit"
               value="Save" />
        <p class="error"
           v-if="submitStatus === 'ERROR'">Is everything filled in correctly?</p>
      </div>
    </form>

    <button>
      <router-link to="/products">Back</router-link>
    </button>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

import { validationMixin } from 'vuelidate';
import { required, minLength } from 'vuelidate/lib/validators';

import { getProductById, saveProduct } from '@/services/product.service';
import { Product } from '@/models/product';

@Component({
  validations: {
    title: { required },
    sku: { required },
    desc: { required },
    image: { required },
    basePrice: { required },
    price: { required },
    stocked: { required },
    // product: {
    //   title: { required },
    // },
  },
} as any)
export default class ProductDetail extends Vue {
  product: Product = new Product();

  // alles plat trekken voor Vuelidate
  title: string = '';
  sku: string = '';
  desc: string = '';
  image: string = '';
  basePrice: number = 0;
  price: number = 0;
  stocked: boolean = false;
  submitStatus: string = '';

  onSubmit() {
    if (this.$v.$invalid) {
      this.$v.$touch();
      this.submitStatus = 'ERROR';
      return;
    }
    this.submitStatus = 'OK';

    this.updateProduct({
      title: this.title,
      sku: this.sku,
      desc: this.desc,
      image: this.image,
      basePrice: this.basePrice,
      price: this.price,
      stocked: this.stocked,
    });
    saveProduct(this.product).then(status => {
      this.$router.push({ name: 'products' });
    });
  }

  setFormValue(product: Product) {
    this.title = product.title;
    this.sku = product.sku;
    this.desc = product.desc;
    this.image = product.image;
    this.basePrice = product.basePrice;
    this.price = product.price;
    this.stocked = product.stocked;
  }

  updateProduct(formValues: Object) {
    Object.assign(this.product, formValues);
  }

  created() {
    const id = this.$route.params.id;
    if (id && id !== 'add') {
      getProductById(this.$route.params.id).then(product => {
        this.setFormValue(product);
      });
    }
  }
}
</script>

<style lang="scss" scoped>
$red: rgb(212, 29, 29);
form {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  margin: 20px 0;
}
.form-goup {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: flex-start;
  margin: 10px 0;
  width: 400px;

  &.inline {
    flex-direction: row;
    align-items: center;
    input {
      width: auto;
    }
    label {
      margin-bottom: 0;
    }
  }

  &.form-group--error input,
  &.form-group--error textarea {
    border: 1px solid $red;
  }

  label {
    font-size: 18px;
    margin: 0 20px 5px 0;
  }
  input,
  textarea {
    border: 1px solid #b5b5b5;
    padding: 10px;
    border-radius: 3px;
    width: 100%;

    &:focus {
      outline: 0;
    }
  }

  input[type='submit'] {
    border: none;
  }

  textarea {
    resize: none;
    height: 150px;
  }

  .error {
    margin: 5px 0;
    color: $red;
  }
}
</style>
